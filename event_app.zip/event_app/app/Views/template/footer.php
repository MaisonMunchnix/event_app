<footer class="bg-dark text-white py-4 mt-5">
    <div class="container text-center">
        <h4>PHP WEB APPLICATION FRAMEWORK: CODEIGNITER 4 (INTERMEDIATE)</h4>

        <p class="mb-2">
            <?=  date('Y') ?> Event Management System - All Rights Reserved
        </p>

        <small class="text-secondary">
            Developed using CodeIgniter 4 & Bootstrap 5
        </small>

    </div>
</footer>
<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-..." crossorigin="anonymous">
</head>
<body>
    
</body>
</html> -->
